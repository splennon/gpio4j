#include <iostream>
#include <vector>
#include <stdexcept>
#include <cstdint>
#include <algorithm>

enum class MessageType {
    READ
    // Add other message types as needed
};

class LineByte {
public:
    LineByte(int value) : value_(value) {}

    std::vector<uint8_t> getHiLo() const {
        return {static_cast<uint8_t>((value_ >> 8) & 0xFF), static_cast<uint8_t>(value_ & 0xFF)};
    }

    int asInt() const {
        return value_;
    }

private:
    int value_;
};

class Read {
public:
    Read() : pin_(0) {}
    Read(int pin) : pin_(pin) {}

    Read& parse(const std::vector<uint8_t>& wireData) {
        if (wireData.size() < 2) {
            throw std::runtime_error("Incorrect number of bytes");
        }

        pin_ = LineByte((wireData[0] << 8) | wireData[1]).asInt();
        return *this;
    }

    std::vector<uint8_t> wireData() const {
        if (pin_ == 0) {
            throw std::runtime_error("Pin is not set when generating wire data");
        }

        return LineByte(pin_).getHiLo();
    }

    MessageType getType() const {
        return MessageType::READ;
    }

    int getPin() const {
        return pin_;
    }

    void setPin(int pin) {
        pin_ = pin;
    }

    Read withPin(int pin) const {
        return Read(pin);
    }

private:
    int pin_;
};

