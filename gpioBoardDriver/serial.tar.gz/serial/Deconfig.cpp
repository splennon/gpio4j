#include <iostream>
#include <vector>
#include <stdexcept>
#include <cstdint>

class LineByte {
public:
    LineByte(int pin) {
        // Assuming getHiLo() returns a vector of bytes
        hiLo = { static_cast<uint8_t>((pin >> 8) & 0xFF), static_cast<uint8_t>(pin & 0xFF) };
    }

    LineByte(const std::vector<uint8_t>& bytes) {
        if (bytes.size() != 2) throw std::invalid_argument("Invalid byte array size");
        pin = (static_cast<int>(bytes[0]) << 8) | static_cast<int>(bytes[1]);
    }

    std::vector<uint8_t> getHiLo() const {
        return hiLo;
    }

    int asInt() const {
        return pin;
    }

private:
    int pin;
    std::vector<uint8_t> hiLo;
};

enum class MessageType {
    DECONFIG
};

class Message {
public:
    virtual ~Message() = default;
    virtual Message* parse(std::istream& wireData) = 0;
    virtual std::vector<uint8_t> wireData() = 0;
    virtual MessageType getType() = 0;
};

class Deconfig : public Message {
public:
    Deconfig() : pin(0) {}
    Deconfig(int pin) : pin(pin) {}

    Deconfig* parse(std::istream& wireData) override {
        if (wireData.rdbuf()->in_avail() < 2) throw std::runtime_error("Incorrect number of bytes");

        std::vector<uint8_t> bytes(2);
        wireData.read(reinterpret_cast<char*>(bytes.data()), 2);
        pin = LineByte(bytes).asInt();
        return this;
    }

    std::vector<uint8_t> wireData() override {
        if (!pin) throw std::runtime_error("Pin is not set when generating wire data");

        LineByte lineByte(pin);
        return lineByte.getHiLo();
    }

    MessageType getType() override {
        return MessageType::DECONFIG;
    }

private:
    int pin;
};

