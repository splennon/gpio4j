#include "Notify.h"

  Notify(int pin, std::unique_ptr<Message> data, int64_t timestamp)
    : pin(pin), data(std::move(data)), timestamp(timestamp) {}

  void parse(std::istream& wireData) override {
    throw std::runtime_error("Read not implemented");
  }

  void wireData(std::ostream& wireData) override {

    std::vector<uint8_t> buffer(2);
    wireData.read(reinterpret_cast<char*>(buffer.data()), 2);
    pin = LineByte(buffer).asInt();

    int messageTypeId = wireData.get();
    auto messageType = MessageType::forId(messageTypeId);
    if (!messageType) {
      throw std::runtime_error("Invalid message type");
    }
    data = messageType->newInstance();
    data->parse(wireData);

    int64_t l = 0;
    for (int i = 0; i < 8; ++i) {
      wireData.read(reinterpret_cast<char*>(buffer.data()), 2);
      l = (l << 8) | LineByte(buffer).asInt();
    }
    timestamp = l;

    return *this;
  }

  MessageType getType() const override {
    return MessageType::NOTIFY;
  }

  // Getters and setters
  int getPin() const {
    return pin;
  }
  void setPin(int p) {
    pin = p;
  }

  const Message* getData() const {
    return data.get();
  }
  void setData(std::unique_ptr<Message> d) {
    data = std::move(d);
  }

  int64_t getTimestamp() const {
    return timestamp;
  }
  void setTimestamp(int64_t t) {
    timestamp = t;
  }
};
