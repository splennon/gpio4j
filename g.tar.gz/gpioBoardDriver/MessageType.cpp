#include "MessageType.h"

class MessageTypeHelper {
public:
  static uint8_t getId(MessageType type) {
    return static_cast<uint8_t>(type);
  }

  static std::optional<MessageType> forId(uint8_t id) {
    for (int i = static_cast<uint8_t>(MessageType::READ); i <= static_cast<uint8_t>(MessageType::NOTIFY); ++i) {
      if (id == i) {
        return static_cast<MessageType>(i);
      }
    }
    return std::nullopt;
  }

  static std::unique_ptr<Message> newInstance(MessageType type) {
    switch (type) {
      case MessageType::CONFIG:
        return std::make_unique<Config>();
      case MessageType::DIGITAL:
        return std::make_unique<Digital>();
      case MessageType::DECONFIG:
        return std::make_unique<Deconfig>();
      case MessageType::DUMP:
        return std::make_unique<Dump>();
      case MessageType::INTERRUPT:
        return std::make_unique<Interrupt>();
      case MessageType::READ:
        return std::make_unique<Read>();
      case MessageType::WRITE:
        return std::make_unique<Write>();
      case MessageType::ANALOG:
        return std::make_unique<Analog>();
      case MessageType::NOTIFY:
        return std::make_unique<Notify>();
      default:
        return nullptr;
    }
  }
};
