#ifndef SETTINGS_H
#define SETTINGS_H

constexpr int SERIAL_BAUD = 9600;

constexpr int SERIAL_TIMEOUT=1000;

constexpr int BUFFER_SIZE=1024;

#endif // SETTINGS_H
