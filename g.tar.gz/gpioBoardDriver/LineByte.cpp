#include "LineByte.h"

public:

LineByte(uint8_t b) {
  data = b;
}

LineByte(uint8_t hi, uint8_t lo) {
  if ((hi & 0b11110000) != 0) {
    throw std::invalid_argument("Hi byte contains more than four bits: " + std::bitset<8>(hi).to_string());
  }

  if ((lo & 0b11110000) != 0) {
    throw std::invalid_argument("Lo byte contains more than four bits: " + std::bitset<8>(lo).to_string());
  }

  data = hi & 0b00001111;
  data = (data << 4) | (lo & 0b00001111);
}

LineByte(const std::vector<uint8_t>& ba)
  : LineByte(ba[0], ba[1]) {}

char asByte() const {
  return data;
}

char getHi() const {
  return static_cast<uint8_t>((data & 0b11110000) >> 4);
}

char getLo() const {
  return static_cast<uint8_t>(data & 0b00001111);
}

std::vector<char> getHiLo() const {
  return { getHi(), getLo() };
}

std::string toString() const {
  return std::bitset<8>(data).to_string();
}
}
;
