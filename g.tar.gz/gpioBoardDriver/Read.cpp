#include "Read.h"

Read(int pin) : pin_(pin) {}

void parse(std::istream& wireData) override {
  if (wireData.size() < 2) {
    throw std::runtime_error("Incorrect number of bytes");
  }

  pin_ = LineByte((wireData[0] << 8) | wireData[1]).asInt();
  return *this;
}

void wireData(std::ostream& wireData) const override {
  throw std::runtime_error("Write not implemented");
}

MessageType getType() const {
  return MessageType::READ;
}

int getPin() const {
  return pin_;
}

void setPin(int pin) {
  pin_ = pin;
}

Read withPin(int pin) const {
  return Read(pin);
}
